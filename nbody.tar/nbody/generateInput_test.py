import numpy as np
import random
import time

G = 6.67e-11


mass_list = []
a_list   = []
phi_list = []
x_list   = []
y_list   = []
r_list   = []
vx_list  = []
vy_list  = []
v_list   = []
N_list   = []
pid_list = []
step_list = []


N = int(input("Enter number of objects: "))

for elem in range(0,N):
    N_list.append(elem)


for i in range(0,N):
    phi = random.uniform(0, 1)  * 2 *np.pi # Generate random initial angle in radians
    phi_list.append(phi)


for j in range(0,N):
    a_j = (float(input("Enter the semi-major axis, a, for object %d: " % (j+1,)))) # The %d takes on the value for the object index
    a_list.append(a_j)

for k in range(0,N):
    Ms = (float(input("Enter the mass, Ms, for object %d, in solar masses: " % (k+1,)))) # The %d takes on the value for the object index
    mass_list.append(Ms)



def calcx(a,phi):
    x_list.append(a*np.cos(phi))

def calcy(a,phi):
    y_list.append(a*np.sin(phi))

def calcr(x,y):
    r_list.append(np.sqrt(x**2+y**2))

def calcv(a,Ms):
    v_list.append((((G*(Ms*2e30))/(a*1.496e11))**0.5)/1000) # Assuming Kepleriean motion, we have to convert the mass to kg and a to m then, at the end, divide by 1000 to get v in km/s

def calcvx(v,a,y):
    vx_list.append(-v*(y/a))

def calcvy(v,a,x):
    vy_list.append(-v*(x/a))


for a, phi in zip(a_list, phi_list):
    calcx(a,phi)
for a, phi in zip(a_list, phi_list):
    calcy(a,phi)
for x, y in zip(x_list, y_list):
    calcr(x,y)
for a, Ms in zip(a_list, mass_list):
    calcv(a,Ms)
for v, a, y in zip(v_list,a_list,y_list):
    calcvx(v,a,y)
for v, a, x in zip(v_list,a_list,x_list):
    calcvy(v,a,x)







for elem in N_list:
    pid = random.randint(10000,99999)
    pid_list.append(pid)

for elem in N_list:
    step= random.randint(10000,99999)
    step_list.append(step)

time = 4.1176e+04
inputfile = open("/Users/dimitris/nbodyinputfile.dat", 'w')
print("",N, "sinks", file=inputfile)
print("id/pid/step/time(yr)/mass(Msun)/x/y/z/r(AU)/vx/vy/vz/v(km/s)", file = inputfile)
for N,pid,step,Ms,x,y,r,vx,vy,v in zip(N_list,pid_list,step_list,mass_list,x_list,y_list,r_list,vx_list,vy_list,v_list):
    print("%d %d %d %d %f %f %f %f %f %f %f" % ((N+1),pid,step,time,Ms,x,y,r,vx,vy,v), file = inputfile)
print("The input file is saved in this directory under the file name 'inputfile'. ")
