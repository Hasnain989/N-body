/* ACCEL.C
   D. A. Hubber 21/11/2006 
   Calculates acceleration and jerk of all particles
   ------------------------------------------------------- */

#include <stdio.h>
#include <math.h>

#ifdef WSMOOTHING
extern double rsink;
#endif

/* ------------------------------------------------------- */
void accel(int N, double r[], double v[], double a[],
	   double aone[], double m[])
{
  int i,j,k;
  double rij[3],vij[3];
  double dist,dist2,dist3,rv;
  double invdist,invdist2,invdist3;
  double atemp, jtemp;

#ifdef WSMOOTHING
  double s,s2,s3;
  double Wstar;
  double dWds;
  double dWdt;
#endif

#ifdef DEBUG1
  printf("Calculating accel and jerk\n");
#endif

/* ------------------------------------------------------- */
#ifdef WSMOOTHING
// Loop over all particles
  for (i=0; i<N-1; i++)
    {
      for (j=i+1;j<N; j++)
	{
	  dist2=0.0;  
	  rv=0.0;

	  for (k=0; k<NDIM; k++)
	    {
	      rij[k]=r[NDIM*i + k] - r[NDIM*j + k];
	      vij[k]=v[NDIM*i + k] - v[NDIM*j + k];
	      dist2=dist2 + rij[k]*rij[k];
	      rv=rv + rij[k]*vij[k];
	    }
	  dist=sqrt(dist2);
	  dist3=dist2*dist;
	  invdist=1.0/dist;
	  invdist2=1.0/dist2;
	  invdist3=1.0/dist3;

	  s=dist/rsink;
	  s2=s*s;
	  s3=s2*s;

	  if (s<=1)
	    {
	      Wstar=4.0*s3/3.0 - 6.0*s3*s2/5.0 + 0.5*s3*s3;
	      dWds=4.0*s2 - 6.0*s3*s + 3.0*s3*s2;
	    }
	  else if (s<=2)
	    {
	      Wstar=8.0*s3/3.0 - 3.0*s3*s + 6.0*s3*s2/5.0 - 
		s3*s3/6.0 - 0.2;
	      dWds=8.0*s2 - 12.0*s3 + 6.0*s3*s - s3*s2;
	    }
	  else
	    {
	      Wstar=1.0;
	      dWds=0.0;
	    }

	  dWdt=dWds*rv*invdist/rsink;

	  for (k=0; k<NDIM; k++)
	    {
	      atemp=Wstar*rij[k]/dist3;
	      jtemp=(Wstar*vij[k] + dWdt*rij[k] - 
		     3*Wstar*rv*rij[k]*invdist2)*invdist3;
	      a[NDIM*i + k]=a[NDIM*i + k] - m[j]*atemp;
	      a[NDIM*j + k]=a[NDIM*j + k] + m[i]*atemp;
	      aone[NDIM*i + k]=aone[NDIM*i + k] - m[j]*jtemp;
	      aone[NDIM*j + k]=aone[NDIM*j + k] + m[i]*jtemp;
	    }
	}
    }


#else
/* ------------------------------------------------------- */
// Loop over all particles
  for (i=0; i<N-1; i++)
    {

      for (j=i+1;j<N; j++)
	{
	  dist2=0.0;  
	  rv=0.0;

	  for (k=0; k<NDIM; k++)
	    {
	      rij[k]=r[NDIM*i + k] - r[NDIM*j + k];
	      vij[k]=v[NDIM*i + k] - v[NDIM*j + k];
	      dist2=dist2 + rij[k]*rij[k];
	      rv=rv + rij[k]*vij[k];
	    }
	  dist=sqrt(dist2);
	  dist3=dist2*dist;
	  invdist2=1.0/dist2;
	  invdist3=1.0/dist3;

	  for (k=0; k<NDIM; k++)
	    {
	      atemp=rij[k]/dist3;
	      jtemp=(vij[k] - 3*rv*rij[k]*invdist2)*invdist3;
	      a[NDIM*i + k]=a[NDIM*i + k] - m[j]*atemp;
	      a[NDIM*j + k]=a[NDIM*j + k] + m[i]*atemp;
	      aone[NDIM*i + k]=aone[NDIM*i + k] - m[j]*jtemp;
	      aone[NDIM*j + k]=aone[NDIM*j + k] + m[i]*jtemp;
	    }
	}
    }
#endif
/* ------------------------------------------------------- */

  return;
}
