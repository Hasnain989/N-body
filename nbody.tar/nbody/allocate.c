/* ALLOCATE.C
   D. A. HUBBBER - 16/5/2007
   Allocates main data arrays 
   --------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include "extern_global.h"

/* --------------------------------------------------- */
void allocate(void)
{
#ifdef DEBUG1
  printf("Allocating memory.\n");
#endif

  a = malloc(NDIM*N*sizeof(double));
  a0 = malloc(NDIM*N*sizeof(double));
  aone = malloc(NDIM*N*sizeof(double));
  a0one = malloc(NDIM*N*sizeof(double));
  atwo = malloc(NDIM*N*sizeof(double));
  athree = malloc(NDIM*N*sizeof(double));
  m = malloc(N*sizeof(double));
  r = malloc(NDIM*N*sizeof(double));
  r0 = malloc(NDIM*N*sizeof(double));
  v = malloc(NDIM*N*sizeof(double));
  v0 = malloc(NDIM*N*sizeof(double));

  return;
}
