// CORRECTION.C
// D. A. Hubber - 21/11/2006
// Correction step for Hermite scheme
// -------------------------------------------------------

#include <stdio.h>
#include "extern_global.h"

// -------------------------------------------------------
void correction(void)
{
  int i,k;
  double dt3;
  double dt4;
  double dt5;
  double invdt;
  double invdt2;
  double inv6=1.0/6.0;
  double inv24=1.0/24.0;
  double inv120=1.0/120.0;

  dt3=dt*dt*dt;
  dt4=dt3*dt;
  dt5=dt4*dt;

  invdt=1.0/dt;
  invdt2=invdt*invdt;

// Calculate higher derivatives
  for (i=0; i<N; i++)
    {

      for (k=0; k<NDIM; k++)
	{
	  atwo[NDIM*i + k]=atwo[NDIM*i + k] 
	    + 2.0*(-3.0*(a0[NDIM*i + k] - a[NDIM*i + k]) - 
		   (2.0*a0one[NDIM*i + k] + aone[NDIM*i + k])*dt)*invdt2;
	  athree[NDIM*i + k]=athree[NDIM*i + k]
	    + 6.0*(2.0*(a0[NDIM*i + k] - a[NDIM*i + k]) + 
		   (a0one[NDIM*i + k] + aone[NDIM*i + k])*dt)*invdt2*invdt;
	}
    }

// Correct positions and velocities
  for (i=0; i<N; i++)
    {
      for (k=0; k<NDIM; k++)
	{
	  r[NDIM*i + k]=r[NDIM*i + k] + inv24*atwo[NDIM*i + k]*dt4 + 
	    inv120*athree[NDIM*i + k]*dt5;
	  v[NDIM*i + k]=v[NDIM*i + k] + inv6*atwo[NDIM*i + k]*dt3 + 
	    inv24*athree[NDIM*i + k]*dt4;
	}
    }

  return;
}
