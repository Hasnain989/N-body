/* UNITS.C
   D. A. Hubber - 27/11/2006
   Prepare conversion to dimensionless units.  
   To convert code units to specified unit (e.g. pc, myr, msun), 
   then multiply by rscale, mscale, tscale etc.
   To convert to cgs units, multiply by rscale*rcgs, 
   mscale*mcgs, tscale*tcgs etc.
   ------------------------------------------------------------- */

#include <stdio.h>
#include <string.h>
#include <math.h>
#include "extern_global.h"

/*-------------------------------------------------------------- */
void units(void)
{

#ifdef DEBUG1
  printf("Setting up scaling units for simulation.\n");
#endif


/* Set all scaling variables to zero if we are using the 
   dimensionless flag
   ------------------------------------------------------------- */
#ifdef DIMENSIONLESS
  rscale=1.0;
  mscale=1.0;
  tscale=1.0;
  vscale=1.0;
  energyscale=1.0;
  
  rcgs=1.0;
  mcgs=1.0;
  tcgs=1.0;
  vcgs=1.0;
  energycgs=1.0;
  
  strcpy(runit,"\0");
  strcpy(munit,"\0");
  strcpy(tunit,"\0");
  strcpy(vunit,"\0");
  strcpy(energyunit,"\0");
  
/*-------------------------------------------------------------- */
#else
/* If we are using scaled units
   ------------------------------------------------------------- */

  /* Length unit in cgs units (cm) */
  if (strncmp(runit,"pc",2)==0)
    rcgs=r_pc;
  else if (strncmp(runit,"au",2)==0)
    rcgs=r_au;
  else if (strncmp(runit,"r_sun",5)==0)
    rcgs=r_sun;
  else if (strncmp(runit,"r_earth",7)==0)
    rcgs=r_earth;
  else if (strncmp(runit,"cm",2)==0)
    rcgs=1.0;
  
  
  
  /* Mass units in cgs units (g) */
  if (strncmp(munit,"m_sun",4)==0)
    mcgs=m_sun;
  else if (strncmp(munit,"m_jup",4)==0)
    mcgs=m_jup;
  else if (strncmp(munit,"m_earth",6)==0)
    mcgs=m_earth;
  else if (strncmp(munit,"g",1)==0)
    mcgs=1.0;
  
  
  
  /* Calculate time units in cgs units (s) */
  if (strncmp(tunit,"myr",3)==0)
    tcgs=myr;
  else if (strncmp(tunit,"yr",2)==0)
    tcgs=yr;
  else if (strncmp(tunit,"day",3)==0)
    tcgs=day;
  else if (strncmp(tunit,"s",1)==0)
    tcgs=1.0;
  
  tscale=pow(rscale*rcgs, 1.5) / sqrt(mscale*mcgs*G_const);
  tscale=tscale/tcgs;
  
  
  /* Velocity units in cgs units (i.e. cm/s) */
  vscale=rscale*rcgs/(tscale*tcgs);
  
  if (strncmp(vunit,"km/s",4)==0)
    vcgs=km_cm;
  if (strncmp(vunit,"au/yr",5)==0)
    vcgs=r_au/yr;
  if (strncmp(vunit,"cm/s",4)==0)
    vcgs=1.0;
    
  vscale=vscale/vcgs;
  
  /* Energy in chosen units and cgs units (i.e. erg = g cm^2/s^2) */
  if (strncmp(energyunit,"cgs",3)==0)
    {
      energyscale=mscale*rscale*rscale/tscale/tscale;
      energycgs=mcgs*rcgs*rcgs/tcgs/tcgs;
    }
  
    
#endif
/*--------------------------------------------------------------- */


  /* Print out scaling factors */
  printf("Length units   = %g %s \n",rscale,runit);
  printf("Mass units     = %g %s \n",mscale,munit);
  printf("Time units     = %g %s \n",tscale,tunit);
  printf("Velocity units = %g %s \n",vscale,vunit);
  printf("Energy units   = %g %s \n",energyscale,energyunit);


  return;
}
