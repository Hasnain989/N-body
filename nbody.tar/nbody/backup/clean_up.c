/* CLEAN_UP.C
   D. A. Hubber - 17/5/2007
   Frees up memory after simulation finishes
   ------------------------------------------------------------ */

#include <stdio.h>
#include <stdlib.h>
#include "extern_global.h"

void clean_up(void)
{

#ifdef DEBUG1
  printf("Cleaning up memory.\n");
#endif

  free(a);
  free(a0);
  free(aone);
  free(a0one);
  free(atwo);
  free(athree);
  free(m);
  free(r);
  free(r0);
  free(v);
  free(v0);

  return;
}
