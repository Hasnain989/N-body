// SIMPLE_BINARY_SEARCH.C
// D. A. Hubber - 24/11/2006
// Searches for bound binaries by looking at two-body energies, 
// but only looking at particular cases for simplicity
// -----------------------------------------------------------

#include <stdio.h>
#include <math.h>

// -----------------------------------------------------------
void simple_binary_search(int N, double r[][3], double v[][3], double m[])
{
  int i,j,k,kk;
  int nbin,i2,j2,k1,k2;

  double dr[3];
  double dv[3];
  double vmag2, rmag2, rmag;
  double mu, binen;


#ifdef DEBUG1
  printf("In binary_search.....\n");
#endif

// First check if brown dwarfs are bound together

  printf("Computing energy of brown dwarf pair...\n");

  i=1;
  j=2;

  for (k=0; k<3; k++)
    {
      dr[k]=r[i][k] - r[j][k];
      dv[k]=v[i][k] - v[j][k];
    }
  rmag2=dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2];
  vmag2=dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2];
  rmag=sqrt(rmag2);

  mu=m[i]*m[j]/(m[i] + m[j]);
  binen=0.5*mu*vmag2 - (m[i]*m[j])/rmag;
  printf("%d %d %lf\n",i,j,binen);


// if brown dwarf binaries are bound, find if they are bound to 
// any of the other two stars
  if (binen<0.0)
    {
      int p,pmin;
      double rcom[3];
      double vcom[3];
      double mtot;
      double emin,binen2;

      mtot=m[i]+m[j];
      for (k=0; k<3; k++)
	{
	  rcom[k]=(m[i]*r[i][k] + m[j]*r[j][k])/mtot; 
	  vcom[k]=(m[i]*v[i][k] + m[j]*v[j][k])/mtot;
	}

      emin=9.0e20;

      for (p=0; p<2; p++)
	{
	  p=p*3;
	  for (k=0; k<3; k++)
	    {
	      dr[k]=rcom[k] - r[p][k];
	      dv[k]=vcom[k] - v[p][k];
	    }

	  rmag2=dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2];
	  vmag2=dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2];
	  rmag=sqrt(rmag2);

	  mu=mtot*m[p]/(mtot + m[p]);
	  binen2=0.5*mu*vmag2 - (mtot*m[p])/rmag;

	  printf("%d %lf\n",p,binen2);

	  if (binen2<emin)
	    {
	      pmin=p;
	      emin=binen;
	    }
	}
      if (emin<0.0)
	{
	  printf("Triple found - binary[%d][%d] + single %d\n",i,j,pmin);
	}
    }

}





