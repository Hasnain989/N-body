/* TIMESTEP.C
   D. A. Hubber - 21/11/2006
   Calculates a global timestep for all particles
   -------------------------------------------------------------- */

#include <stdio.h>
#include <math.h>
#include "extern_global.h"

/* -------------------------------------------------------------- */
void basic_timestep(void)
{
  int i,j,k,power;
  double dr[3],dist_mag;
  double dv[3],vel_mag;
  double da[3],accel_mag;
  double dt1,dt2;
  double dtnextout;

#ifdef DEBUG1
  printf("Calculating timestep for all particles\n");
#endif

  dt=9.e20;
  dtnextout=1.0001*(toutput-toutlast);

  for (i=0; i<N-1; i++)
    {
      for (j=i+1; j<N; j++)
	{

	  for (k=0; k<3; k++)
	    {
	      dr[k]=r0[NDIM*i + k] - r0[NDIM*j + k];
	      dv[k]=v0[NDIM*i + k] - v0[NDIM*j + k];
	      da[k]=a0[NDIM*i + k] - a0[NDIM*j + k];
	    }

	  dist_mag=sqrt(dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2]);
	  vel_mag=sqrt(dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2]);
	  accel_mag=sqrt(da[0]*da[0] + da[1]*da[1] + da[2]*da[2]);

	  dt1=eta1*dist_mag/vel_mag;
	  dt2=eta1*sqrt(dist_mag/accel_mag);

	
	  /* Select smallest global timestep */
	  if (dt1<dt) dt=dt1;
	  if (dt2<dt) dt=dt2;
	}
    }


// Quantize timestep to powers of 2
  dt1=1.0;
  power=0;
  do
    {
      dt1=dt1/2.0;
      power=power + 1;
    } 
  while (dt1>dt);
  
  //  dt=1.0e-3;

#ifdef DEBUG2
  printf("Global timestep = %lf  %lf\t",dt, dt1);
  printf("Power = %d\n",power);
#endif  

  //dt=dt1;

  dt=fmin(dt,dtnextout);

  return;
}
