// PREDICT.C
// D. A. Hubber - 21/11/2006
// Predict positions and velocities of particles to 2nd order
// --------------------------------------------------------

#include <stdio.h>
#include "extern_global.h"

// --------------------------------------------------------
void predict(void)
{
  int i,k;
  double dt2;
  double dt3;
  double onesixth=1.0/6.0;

#ifdef DEBUG1
  printf("Predicting particle properties...\n");
#endif

  dt2=dt*dt;
  dt3=dt2*dt;

  for(i=0; i<N; i++)
    {

      for (k=0; k<NDIM; k++)
	{
	  r[NDIM*i + k]=r0[NDIM*i + k] + v0[NDIM*i + k]*dt + 
	    0.5*a0[NDIM*i + k]*dt2 + onesixth*a0one[NDIM*i + k]*dt3;
	  v[NDIM*i + k]=v0[NDIM*i + k] + a0[NDIM*i + k]*dt + 
	    0.5*a0one[NDIM*i + k]*dt2;
	}
    }

  return;
}
