/* CONVERT_TO_CODE_UNITS.C
   D. A. Hubber - 28/11/2006
   Convert all simulation data from real units to dimensionless 
   code units using scaling factors calculated in units.c
   -------------------------------------------------------------- */

#include <stdio.h>
#include "extern_global.h"

/* -------------------------------------------------------------- */
void convert_to_code_units(void)
{
  int p;         /* counter to loop over particles  */
  int k;         /* counter to loop over dimensions */

#ifdef DEBUG1
  printf("Converting to dimensionless code units.\n");
#endif

/* Scale main particle properties */
  for (p=0; p<N; p++)
    {
      for (k=0; k<NDIM; k++)
	{
	  r0[NDIM*p + k] /= rscale;
	  v0[NDIM*p + k] /= vscale;
	}
      m[p] /= mscale;
    }


/* Scale time variables */
  tmax /= tscale; 
  dtout /= tscale; 
  sphtime /=tscale;

#ifdef DEBUG2
  for (p=0; p<N; p++)
    {
      printf("r[%d] : %g %g %g\n",p,r0[NDIM*p],r0[NDIM*p+1],r0[NDIM*p+2]);
      printf("v[%d] : %g %g %g\n",p,v0[NDIM*p],v0[NDIM*p+1],v0[NDIM*p+2]);
    }
#endif


  return;
}
