// IC.C
// D. A. Hubber - 20/11/2006
// Creates initial conditions for BD-BD binary simulations
// ----------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "extern_global.h"


void ic(double numb[6])
{
  int i,k;
  double angle;
  double vpert[3];
  double bpert[2];
  double vunit[3];
  double vmag2, vmag;
  double vrot;
  double mtot;

#ifdef DEBUG1
  printf("In ic.....\n");
#endif

  angle=3.1415*numb[0];
  vpert[0]=2.0*numb[1] - 1.0;   
  vpert[1]=2.0*numb[2] - 1.0;   
  vpert[2]=2.0*numb[3] - 1.0;
  bpert[0]=2.0*numb[4] - 1.0;   
  bpert[1]=2.0*numb[5] - 1.0;

  printf("Angle - %lf\n",angle);


// Set masses of components
  m[0]=mprimary;
  m[1]=mbinary/2.0;
  m[2]=mbinary/2.0;
  mtot=mprimary+mbinary;

// Set position and velocity of primary star
  r0[0][0]=-mbinary/mtot;
  v0[0][1]=-mbinary/mtot;


// Set BD position and velocities
  vrot=sqrt(mbinary/(8.0*rbinary));

#ifdef DEBUG1
  printf("vrot - %lf\n",vrot);
#endif

  r0[1][0]=mprimary/mtot + rbinary*cos(angle);
  r0[1][1]=rbinary*sin(angle);
  v0[1][0]=-vrot*sin(angle);
  v0[1][1]=mprimary/mtot + vrot*cos(angle);

  r0[2][0]=mprimary/mtot - rbinary*cos(angle);
  r0[2][1]=-rbinary*sin(angle);
  v0[2][0]=vrot*sin(angle);
  v0[2][1]=mprimary/mtot - vrot*cos(angle);


// Set mass, position and velocity of perturber
  m[3]=1.0;

  vmag2=vpert[0]*vpert[0] + vpert[1]*vpert[1] + vpert[2]*vpert[2];
  vmag=sqrt(vmag2);
  for (k=0; k<3; k++)  
    {
      vunit[k]=vpert[k]/vmag;
      v0[3][k]=vpertmag*vunit[k];
    }

  // Extrapolate initial position of star to edge of sphere
  r0[3][0]=rpertmag*bpert[0] - rpertmag*vunit[0];
  r0[3][1]=rpertmag*bpert[1] - rpertmag*vunit[1];
  r0[3][2]=-rpertmag*vunit[2];


#ifdef DEBUG1
  printf("Printing particle data.....\n");
  for (i=0; i<N; i++)
    {
      printf("Mass for %d - %lf\n",i,m[i]);
      printf("Position - %lf\t %lf\t %lf\n",r0[i][0],r0[i][1],r0[i][2]);
      printf("Velocity - %lf\t %lf\t %lf\n",v0[i][0],v0[i][1],v0[i][2]);
    }
#endif

}
