/* PARAMETERS.C
   D. A. Hubber 21/11/2006 
   Reads input parameters from external file
   ---------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include "extern_global.h"

/* ---------------------------------------------------------- */
void parameters(char param_file[20])
{
  FILE *fp = fopen(param_file, "r");

  char sdum[50];

  if (fp != NULL)
    {
#ifdef DEBUG1
      printf("Reading parameter file....\n");
#endif

/* Input file name */
      fscanf(fp,"%s %s",&runid, sdum);
      fscanf(fp,"%s %s",&in_file, sdum);

/* Read in simulation parameters */
      fscanf(fp,"%lf %s",&tmax,sdum);
      fscanf(fp,"%lf %s",&dtout,sdum);

/* Read in scaling preferences */
      fscanf(fp,"%s %s",&runit,sdum);
      fscanf(fp,"%s %s",&munit,sdum);
      fscanf(fp,"%s %s",&tunit,sdum);
      fscanf(fp,"%s %s",&vunit,sdum);
      fscanf(fp,"%s %s",&energyunit,sdum);
      fscanf(fp,"%lf %s",&rscale,sdum);
      fscanf(fp,"%lf %s",&mscale,sdum);

/* Time stepping parameters */
      fscanf(fp,"%lf %s",&eta1,sdum);
      fscanf(fp,"%lf %s",&eta2,sdum);

/* Sink radius (for kernel softened gravity */
      fscanf(fp,"%lf %s",&rsink,sdum);

/* Close file once finished */
      fclose(fp);

#ifdef DEBUG1
      printf("in_file : %s\n",in_file);
      printf("tmax    : %f\n",tmax);
      printf("dtout   : %f\n",dtout);
      printf("eta1    : %f\n",eta1);
      printf("eta2    : %f\n",eta2);
#endif

    }
  else 
    {    
      printf("Unable to open parameter file\n");
      exit(0);
    }

  return;

}
