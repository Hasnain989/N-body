/* BINARY_SEARCH.C
   D. A. Hubber - 24/11/2006
   Searches for bound binaries by looking at two-body energies
   -------------------------------------------------------------- */

#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <math.h>

extern double rscale;               /* length scaling factor   */
extern double mscale;               /* mass scaling factor     */
extern double tscale;               /* time scaling factor     */
extern double vscale;               /* velocity scaling factor */
extern double energyscale;          /* energy scaling factor   */
extern char runid[20];


/* -------------------------------------------------------------- */
void binary_search(N,r,v,m,fname,time,sphtime)
  
  int N; 
double r[];
double v[]; 
double m[];
char fname[30]; 
double time,sphtime;
{
  int i,j,k,kk,idum=0;
  int nbin,i2,j2,k1,k2;
  int ntrip;

  int *binary;
  int *most_bound;
  int *single;
  int *id;
  double mtot;
  int flag;
  double dr[3];
  double dv[3];
  double Lij[3];
  double vmag2, rmag2, rmag;
  double mu,mu1,mu2, binen;
  double sma,sma1,sma2;
  double Lsqd;
  double eccent;
  double period;
  double *energy;
  double x,y,z,vx,vy,vz,lx,ly,lz,l,angle,mass,starx,stary,starz,starvx,starvy,starvz;
  
  FILE *fp;

 
  starx=r[0];
  stary=r[1];
  starz=r[2];
  starvx=v[0];
  starvy=v[1];
  starvz=v[2];

  fp = fopen(fname,"w");

#ifdef DEBUG1
  printf("\n"
	 "----------------------------------------\n"
	 "Searching for binaries\n"
	 "----------------------------------------\n");
#endif

/* Allocate arrays */
  binary = malloc(N*N*sizeof(int));
  most_bound = malloc(N*N*sizeof(int));
  energy = malloc(N*N*sizeof(double));
  single = malloc(N*sizeof(int));
  id= malloc(N*sizeof(int));

/* Initialise variables */
  for (i=0; i<N; i++)
    {
      single[i]=1;
      id[i]=0;
      for (j=0; j<N; j++)  
	{
	  binary[N*i + j] = -1;
	  most_bound[N*i + j] = -1;
	  energy[N*i + j] = 9.9e30;
         
	}
    }

#ifdef DEBUG1
  printf("Computing energies of all pairs...\n");
#endif

flag=1;

while (flag==1) 
{

  for (i=0; i<N; i++)
    {
      for (j=0; j<N; j++)
        {
          binary[N*i + j] = -1;
          most_bound[N*i + j] = -1;
          energy[N*i + j] = 9.9e30;

        }
    }



/* First compute two-body energy of all star pairs */
  for (i=0; i<N; i++)
    {
      for (j=0; j<N; j++)
	{
	  if (i==j || id[i]==1 || id[j]==1) continue;

	  for (k=0; k<NDIM; k++)
	    {
	      dr[k]=r[NDIM*i + k] - r[NDIM*j + k];
	      dv[k]=v[NDIM*i + k] - v[NDIM*j + k];
	    }
	  rmag2=dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2];
	  vmag2=dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2];
	  rmag=sqrt(rmag2);

	  mu=m[i]*m[j]/(m[i] + m[j]);
	  binen=0.5*mu*vmag2 - (m[i]*m[j])/rmag;
	  energy[N*i + j]=binen;
	  // printf("%lf %lf %lf\n",dr[0],dr[1],dr[2]);
#ifdef BINENDEBUG
	  printf("%d %d %lf\n",i,j,binen);
#endif
	}
    }

#ifdef DEBUG1
  printf("Find which stars are most bound....\n");
#endif

/* Find which stars are most bound together 
   --------------------------------------------------------------- */
  for (i=0; i<N; i++)
    {
      for (j=0; j<N; j++)
	{
	  if (i==j || id[j]==1 || id[i]==1) continue;
	  if (energy[N*i + j]<0.0)
	    {
	      k=most_bound[N*i];
	      kk=most_bound[N*i + 1];
	      if (k==-1)
		most_bound[N*i]=j;
	      else if (energy[N*i + j]<energy[N*i + k]) 
		{
		  most_bound[N*i + 1]=most_bound[N*i];
		  most_bound[N*i]=j;
		}
	      else if (energy[N*i+j]<energy[N*i+kk] && kk>-1)
		{
		  most_bound[N*i+1]=j;
		}
	    }
	}
    }

#ifdef DEBUG1
  printf("Identify binaries.....\n");
#endif

/* Now cross-reference all two-body energies to find mutual bound 
   pairs, i.e. binary stars 
   ----------------------------------------------------------------- */
  nbin=0;
  flag=0; 

 for (i=0; i<N; i++)
    {
      if (id[i]==1) continue;

      j=most_bound[N*i];
#ifdef BINENDEBUG
      printf("%d %d \n",i,j);
#endif
      if (most_bound[N*j]==i && i<j && id[j]!=1)
	{
	  if (nbin==0)
	    {
	      fprintf(fp,"-----------------------------------------\n"
		         " ****** Multiple star information  ******\n"
		         "-----------------------------------------\n\n");
	    }


	  binary[N*nbin]=i;
	  binary[N*nbin+1]=j;
	  nbin=nbin+1;

/* Flag stars as not being singles */
	  single[i]=0;
	  single[j]=0;

/* Calculate semi-major axis of both components of the binary */
	  binen=energy[N*i+j];


	  mu=m[i]*m[j]/(m[i] + m[j]);
	  if (m[i]>m[j]) 
	    {
	      sma2 = -mu*m[i]/(2.0*binen);
	      sma1=-mu*m[j]/(2.0*binen);	
	    }
	  else
	    {
	      sma2 = -mu*m[j]/(2.0*binen);
	      sma1=-mu*m[i]/(2.0*binen);	
	    }
	    

/* Calculate angular momentum of binary */
	  for (k=0; k<NDIM; k++)
	    {
	      dr[k]=r[NDIM*i + k] - r[NDIM*j + k];
	      dv[k]=v[NDIM*i + k] - v[NDIM*j + k];
	    }

	  for (k=0; k<3; k++) Lij[k]=0.0; 

#if NDIM==3
	  Lij[0]=dr[1]*dv[2] - dr[2]*dv[1];
	  Lij[1]=dr[2]*dv[0] - dr[0]*dv[2];
#endif
	  Lij[2]=dr[0]*dv[1] - dr[1]*dv[0];


	  Lsqd=mu*mu*(Lij[0]*Lij[0] + Lij[1]*Lij[1] + Lij[2]*Lij[2]);

/* Calculate eccentricity of binary system */
	  /* eccent = 1.0 + (2.0*Lsqd*binen)/(m[i]+m[j]); */

	  eccent =sqrt(1.0 + (2.0*Lsqd*binen)*(m[i]+m[j])/(pow(m[i],3)*pow(m[j],3.)));

/* Calculate period of binary system */
	  period = 2*3.14159*pow(-m[i]*m[j]/(2.*binen),1.5)/sqrt(m[i]+m[j]);

	  /*printf("Binary found [%d][%d]\n",i,j);
	  printf("Bin. En : %g\t (Next bound [%d] : %g)\n",energy[N*i + j],
		 most_bound[N*i + 1],energy[N*i + most_bound[N*i + 1]]);
	  printf("Masses m[%d] : %g\t m[%d] : %g\n",i,m[i],j,m[j]);
	  printf("semi-major axis : %g\n",sma);
	  printf("eccentricity : %g\n",eccent);
	  printf("period : %g\n",period);*/
/* Print info to file */
	  fprintf(fp,"-------------------------------------------------\n");
	  fprintf(fp,"Binary %d\n",nbin);
	  fprintf(fp,"Star %d\t mass : %7.3f\t r : % .4e % .4e % .4e"
		  "\t v : % .4e % .4e % .4e\n",i+1,m[i]*mscale,r[NDIM*i]*rscale,
		  r[NDIM*i+1]*rscale,r[NDIM*i+2]*rscale,
		  v[NDIM*i]*vscale,v[NDIM*i+1]*vscale,v[NDIM*i+2]*vscale);
	  fprintf(fp,"Star %d\t mass : %7.3f\t r : % .4e % .4e % .4e"
		  "\t v : % .4e % .4e % .4e\n",j+1,m[j]*mscale,r[NDIM*j]*rscale,
		  r[NDIM*j+1]*rscale,r[NDIM*j+2]*rscale,v[NDIM*j]*vscale,
		  v[NDIM*j+1]*vscale,v[NDIM*j+2]*vscale);
	  fprintf(fp,"Binding energy............................ % .4e\n",binen*energyscale);
	  fprintf(fp,"semi-major axis of higher-mass component.. % .4e\n",sma1*rscale);
	  fprintf(fp,"semi-minor axis of higher-mass component.. % .4e\n",sma1*rscale*sqrt(1-eccent*eccent));
	  fprintf(fp,"Periastron      of higher-mass component.. % .4e\n",sma1*rscale*(1-eccent));
	  fprintf(fp,"Apoastron       of higher-mass component.. % .4e\n",sma1*rscale*(1+eccent));
	  fprintf(fp,"semi-major axis of lower-mass component... % .4e\n",sma2*rscale);	 
	  fprintf(fp,"semi-minor axis of lower-mass component... % .4e\n",sma2*rscale*sqrt(1-eccent*eccent));
	  fprintf(fp,"Periastron      of lower-mass component... % .4e\n",sma2*rscale*(1-eccent));
	  fprintf(fp,"Apoastron       of lower-mass component... % .4e\n",sma2*rscale*(1+eccent));
	  fprintf(fp,"eccentricity.............................. % .4e\n",eccent);
	  fprintf(fp,"period.................................... % .4e\n\n",period*tscale);
   
/* substitute binary with one body with the total mass mass */

          mtot=m[i]+m[j];
          id[j]=1;
          for (k=0; k<3; k++)
            {
              r[NDIM*i + k]=(m[i]*r[NDIM*i + k] + m[j]*r[NDIM*j + k])/mtot;
              v[NDIM*i + k]=(m[i]*v[NDIM*i + k] + m[j]*v[NDIM*j + k])/mtot;
            }
            m[i]=mtot;

           flag=1;

	  
	   fprintf(fp," * Properties of CM of binary with respect to the central star *\n");
	   fprintf(fp," * id/pid/step/time(yr)/mass(Msun)/x/y/z/r(AU)/vx/vy/vz(km/s)/v/lx/ly/lz/l/angle\n\n");


	     x=(r[NDIM*i]-starx)*rscale;
	     y=(r[NDIM*i+1]-stary)*rscale;
	     z=(r[NDIM*i+2]-starz)*rscale;
	     vx=(v[NDIM*i]-starvx)*vscale;
	     vy=(v[NDIM*i+1]-starvy)*vscale;
	     vz=(v[NDIM*i+2]-starvz)*vscale;
	     mass=m[i]*mscale;
	     
	     lx=mass*(y*vz-z*vy);
	     ly=mass*(z*vx-x*vz);
	     lz=mass*(x*vy-y*vx);
	     l=sqrt(lx*lx+ly*ly+lz*lz);	 

	     if (l>0) 
	       angle=acos(lz/l)*180/3.141519;
	     else
	       angle=-100;
	     
	     
	     fprintf(fp,"%d %d %d %.4e %.4e % .4e % .4e % .4e %.4e % .4e % .4e % .4e %.4e %.4e % .4e % .4e % .4e %.4e\n\n\n",
		     i+1, idum, idum, (time+sphtime)*tscale, m[i]*mscale,
		     (r[NDIM*i]-starx)*rscale,(r[NDIM*i+1]-stary)*rscale,(r[NDIM*i+2]-starz)*rscale,
		     rscale* 
		     pow((r[NDIM*i]-starx)*(r[NDIM*i]-starx)
			 +(r[NDIM*i+1]-stary)*(r[NDIM*i+1]-stary)
			 +(r[NDIM*i+2]-starz)*(r[NDIM*i+2]-starz),0.5),
		     (v[NDIM*i]-starvx)*vscale,(v[NDIM*i+1]-starvy)*vscale,(v[NDIM*i+2]-starvz)*vscale,
		     vscale* 
		     pow((v[NDIM*i]-starvx)*(v[NDIM*i]-starvx)
			 +(v[NDIM*i+1]-starvy)*(v[NDIM*i+1]-starvy)
			 +(v[NDIM*i+2]-starvz)*(v[NDIM*i+2]-starvz),0.5),
		     lx,ly,lz,l,angle);
	   
	   
	   
	   
	   
	}
    }
 
}

/* Loop over single stars and print info */
  fprintf(fp,"-----------------------\n"
	  "Single star information\n"
	  "-----------------------\n\n");

  for (i=0; i<N; i++)
    {
      if (single[i] != 1) continue;



      fprintf(fp,"Star %d\t mass : %7.3f\t r : % .4e % .4e % .4e"
	      "\t v : % .4e % .4e % .4e \t  r* : % .4e\t  v*: % .4e       \n",i+1,m[i]*mscale,
	      r[NDIM*i]*rscale,r[NDIM*i+1]*rscale,r[NDIM*i+2]*rscale,
	      v[NDIM*i]*vscale,v[NDIM*i+1]*vscale,v[NDIM*i+2]*vscale,
	      sqrt(pow(r[NDIM*i]-r[0],2.)+pow(r[NDIM*i+1]-r[1],2.)+pow(r[NDIM*i+2]-r[2],2.))*rscale,
	      sqrt(pow(v[NDIM*i]-v[0],2.)+pow(v[NDIM*i+1]-v[1],2.)+pow(v[NDIM*i+2]-v[2],2.))*vscale
	      );

fprintf(fp," * Properties of single star with respect to the central star *\n");
	   fprintf(fp," * id/pid/step/time(yr)/mass(Msun)/x/y/z/r(AU)/vx/vy/vz(km/s)/v/lx/ly/lz/l/angle\n");
	   
	     x=(r[NDIM*i]-starx)*rscale;
	     y=(r[NDIM*i+1]-stary)*rscale;
	     z=(r[NDIM*i+2]-starz)*rscale;
	     vx=(v[NDIM*i]-starvx)*vscale;
	     vy=(v[NDIM*i+1]-starvy)*vscale;
	     vz=(v[NDIM*i+2]-starvz)*vscale;
	     mass=m[i]*mscale;
	     
	     lx=mass*(y*vz-z*vy);
	     ly=mass*(z*vx-x*vz);
	     lz=mass*(x*vy-y*vx);
	     l=sqrt(lx*lx+ly*ly+lz*lz);

	     if (l>0) 
	       angle=acos(lz/l)*180/3.141519;
	     else
	       angle=-100;
	     
	     
	     fprintf(fp,"%d %d %d %.4e %.4e % .4e % .4e % .4e %.4e % .4e % .4e % .4e %.4e %.4e % .4e % .4e % .4e %.4e\n\n\n",
		     i+1, idum, idum, (time+sphtime)*tscale, m[i]*mscale,
		     (r[NDIM*i]-starx)*rscale,(r[NDIM*i+1]-stary)*rscale,(r[NDIM*i+2]-starz)*rscale,
		     rscale* 
		     pow((r[NDIM*i]-starx)*(r[NDIM*i]-starx)
			 +(r[NDIM*i+1]-stary)*(r[NDIM*i+1]-stary)
			 +(r[NDIM*i+2]-starz)*(r[NDIM*i+2]-starz),0.5),
		     (v[NDIM*i]-starvx)*vscale,(v[NDIM*i+1]-starvy)*vscale,(v[NDIM*i+2]-starvz)*vscale,
		     vscale*
		     pow((v[NDIM*i]-starvx)*(v[NDIM*i]-starvx)
			 +(v[NDIM*i+1]-starvy)*(v[NDIM*i+1]-starvy)
			 +(v[NDIM*i+2]-starvz)*(v[NDIM*i+2]-starvz),0.5),
		     lx,ly,lz,l,angle);

    }


  free(energy); 
  free(most_bound);
  free(binary);

  fclose(fp);

  return;
}





