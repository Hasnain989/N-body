/* READ_IC.C
   D. A. Hubber - 17/5/2007
   Reads initial conditions file supplied by DRAGON Sinks file. 
   --------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include "extern_global.h"
#include <math.h>
/* --------------------------------------------------------------- */
void read_ic(char ic_file[20])
{
  int i;
  int k;
  int p;
  char junk[100];
  int idum1,idum2,idum3;
  double fdum1,fdum2,fdum3;

  double mp;
  double am[NDIM];
  double rp[NDIM];
  double vp[NDIM];

  FILE *fp = fopen( ic_file, "r");

  if (fp != NULL)
    {
#ifdef DEBUG1
      printf("Reading intitial conditions file %s\n",ic_file);
#endif

/* Read in number of bodies */
      fscanf(fp,"%d",&N);
      printf("Number of bodies : %d\n",N);
/* read junk */
      fscanf(fp,"%s",&junk);
      fscanf(fp,"%s",&junk);


/* Now allocate memory once N is known */
      allocate();

/* Zero main arrays */
      zero();

      printf("Reading in particle data.....\n");

/* Now loop over all bodies and read from file */
      for (p=0; p<N; p++)
	{
	  fscanf(fp,"%d %d %d %lf %lf" 
		 "%lf %lf %lf %lf"
		 "%lf %lf %lf %lf \n",
		 &idum1,&idum1,&idum1,&sphtime,
		 &mp,&rp[0],&rp[1],&rp[2],&fdum2,
		 &vp[0],&vp[1],&vp[2],&fdum3,&fdum3,&fdum3,&fdum3,&fdum3,&fdum3);
	  m[p]=mp;
	  for (k=0; k<NDIM; k++) r0[NDIM*p + k]=rp[k];
	  for (k=0; k<NDIM; k++) v0[NDIM*p + k]=vp[k];
	  /* sphtime is time at the end of the SPH simulation in yrs */

	  /* printf("p : %d\t m :%lf\t r : %lf %lf %lf\n",
	     p,m[p],r0[NDIM*p],r0[NDIM*p+1],r0[NDIM*p+2]);
	     printf("\t\t\t v : %lf %lf %lf\n",
	     v0[NDIM*p],v0[NDIM*p+1],v0[NDIM*p+2]);
	     printf("\t\t\t am: %lf %lf %lf\n",
	     am[0],am[1],am[2]);
	     printf("fdum1 : %lf\t fdum2 : %lf\n",fdum1,fdum2);
	     printf("idum1 : %d\t idum2 : %d\t idum3 : %d\n",
	     idum1,idum2,idum3); */ 
	  
	}

      printf("Finished reading in particle data.\n");

    }
  else 
    {    
      printf("Unable to open file %s\n",ic_file);
      exit(0);
    }


  printf("\n:: Verifying particle data ::\n");

   printf("-Number of sinks:%d\n",N-1);
      printf("-SPH time:%.3f (yr)\n\n",sphtime);
  for (p=0; p<N; p++)
    {
      printf("p : %d   m :%.3f   r : % 10.1f % 10.1f % 10.1f     v : % 7.3f % 7.3f % 7.3f\n",
	     p+1,m[p],r0[NDIM*p],r0[NDIM*p+1],r0[NDIM*p+2],
	     v0[NDIM*p],v0[NDIM*p+1],v0[NDIM*p+2]);
      
    }



  return;

}

