/* PROTOTYPE.H
   D. A. Hubber - 17/5/2007
   Subroutine prototypes 
   --------------------------------------------------------------- */

void accel(int, double[],double[],double[],double[],double[]);
void allocate(void);
void basic_timestep(void);
void binary_search(int, double[], double[], double[],char[30],double, double);
//void simple_binary_search(int, double[], double[], double[]);
void clean_up(void);
void COM(void);
void convert_to_code_units(void);
void correction(void);
double energy(int, double *, double *, double *, double mom[NDIM]);
void nextstep(void);
void parameters(char[20]);
void output(FILE *,char[4]);
void predict(void);
void read_ic(char[20]);
void timestep(void);
void units(void);
void zero(void);
