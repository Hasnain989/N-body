/* GLOBAL.H
   D. A. HUBBER - 16/5/2007
   Main global variables
   --------------------------------------------------- */


/* Main particle parameters
   --------------------------------------------------- */
int N;

double *a;
double *a0;
double *aone;
double *a0one;
double *atwo;
double *athree;
double *m;
double *r;
double *r0;
double *v;
double *v0;



/* Time variables 
   --------------------------------------------------- */
int nmax;    // Maximum number of quantised timesteps

int nnow;

double dtmin;
double dtmax;
double time;
double dt;
double toutput;
double toutlast;
double sphtime;



/* Input parameters
   --------------------------------------------------- */
double tmax;                   // Simulation time
double dtout;

double eta1;
double eta2;

double rsink;

char in_file[20];
char runid[20];


/* Scaling variable strings and conversion factors
   ------------------------------------------------------------------ */
char runit[10];                     /* length unit   */
char munit[10];                     /* mass unit     */
char tunit[10];                     /* time unit     */
char vunit[10];                     /* velocity unit */
char energyunit[10];                /* energy unit   */

double rscale;                      /* length scaling factor   */
double mscale;                      /* mass scaling factor     */
double tscale;                      /* time scaling factor     */
double vscale;                      /* velocity scaling factor */
double energyscale;                 /* energy scaling factor   */

double rcgs;                        /* length unit in cgs   */
double mcgs;                        /* mass unit in cgs     */
double tcgs;                        /* time unit in cgs     */
double vcgs;                        /* velocity unit in cgs */
double energycgs;                   /* energy unit in cgs   */


/* Constants
   ------------------------------------------------------------------ */

/* length units in centimetres */
double r_pc=3.086e18;               /* parsec            */
double r_au=1.498e13;               /* astronomical unit */
double r_sun=6.96e10;               /* solar radius      */
double r_earth=6.38e8;              /* Earth radius      */

double pc_au=206265.;               /* parsec (in AU)    */
double km_cm=1.e5;                  /* km (in cm)        */

/* mass units in grams */
double m_sun=1.99e33;               /* solar mass   */
double m_jup=1.9e30;                /* Jupiter mass */
double m_earth=5.98e27;             /* Earth mass   */


/* time units in seconds */
double myr=3.156e13;                /* megayear */
double yr=3.156e7;                  /* year     */
double day=8.64e4;                  /* day      */


/* fundamental constants */
double m_hydrogen=1.67e-24;         /* mass of hydrogen in grams           */
double G_const=6.67e-8;             /* Gravitational constant in cgs units */
double k_boltzmann=1.38e-16;        /* Boltzmann constant in cgs units     */


