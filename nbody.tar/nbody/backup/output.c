/* OUTPUT.C
   D. A. Hubber - 23/11/2006
   Writes simulation information to screen and to file. 
   ------------------------------------------------------------ */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "extern_global.h"
#include <math.h>

extern double rscale;               /* length scaling factor   */
extern double mscale;               /* mass scaling factor     */
extern double tscale;               /* time scaling factor     */
extern double vscale;               /* velocity scaling factor */
extern double energyscale;          /* energy scaling factor   */
extern char runid[20];




/* ------------------------------------------------------------ */
void output(fout, infilename)
     FILE *fout;
     char infilename[5];
{
  int p;
  char star_number[8];
  char temp_file[20];
  char temp_file2[30];
  int idum=0;
  int i,j,k;
  double Lsqd;
  double eccent;
  double period;
  double sma2;
  double vmag2, rmag2, rmag;
  double dr[3];
  double dv[3];
  double Lij[3];
  double mu,binen;
  double *energy;
  FILE *fp;


  energy = malloc(N*N*sizeof(double));
 

/* Write info for each star to individual files
   ------------------------------------------------------------ */

  for (p=0; p<N; p++)
    {

 #ifdef DEBUG1
  printf("Computing energies of all stars paired with central star ...\n");
  printf("p=%d\n",p); 
#endif
  if (p>0) 
    {
      /*    BOUNDNESS INFO  */
      i=0;
      j=p;
      for (k=0; k<NDIM; k++)
	{
	  dr[k]=r[NDIM*i + k] - r[NDIM*j + k];
	  dv[k]=v[NDIM*i + k] - v[NDIM*j + k];
	}
      rmag2=dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2];
      vmag2=dv[0]*dv[0] + dv[1]*dv[1] + dv[2]*dv[2];
      rmag=sqrt(rmag2);
      mu=m[i]*m[j]/(m[i] + m[j]);
      
      binen=0.5*mu*vmag2 - (m[i]*m[j])/rmag;
      energy[N*i + j]=binen;       
      
      mu=m[i]*m[j]/(m[i] + m[j]);
      
      sma2 = -mu*m[0]/(2.0*binen);
      
      /*      Calculate angular momentum of binary */
      for (k=0; k<NDIM; k++)
	{
	  dr[k]=r[NDIM*i + k] - r[NDIM*j + k];
	  dv[k]=v[NDIM*i + k] - v[NDIM*j + k];
	}
      
      for (k=0; k<3; k++) Lij[k]=0.0; 
      
#if NDIM==3
      Lij[0]=dr[1]*dv[2] - dr[2]*dv[1];
      Lij[1]=dr[2]*dv[0] - dr[0]*dv[2];
#endif
      Lij[2]=dr[0]*dv[1] - dr[1]*dv[0];
      
      
      Lsqd=mu*mu*(Lij[0]*Lij[0] + Lij[1]*Lij[1] + Lij[2]*Lij[2]);
          
      if (binen<0)
	
	{   
	  /*  Calculate eccentricity of binary system */
	  
	  eccent =sqrt(1.0 + (2.0*Lsqd*binen)*(m[i]+m[j])/(pow(m[i],3)*pow(m[j],3.)));
	  /* Calculate period of binary system */ 
	  
	  period = 2*3.14159*pow(-m[i]*m[j]/(2.*binen),1.5)/sqrt(m[i]+m[j]);
	
	}	  
      else
	{
	  period=1e10/tscale;
	  eccent=1e10;
	}


      /* END BOUNDNESS INFO */ 
    }

  if (p==0 || nnow==0)
    {
      period=0.;
      eccent=0.;
      binen=0;
      sma2=0;
    }
      sprintf(star_number,".%d",p);
      strcpy(temp_file,runid);
      strcat(temp_file,star_number);
      sprintf(temp_file2,"%s.body.%d.dat",infilename, p+1);

      if (nnow==0) fp = fopen(temp_file2,"w");
      else fp = fopen(temp_file2,"a");

      if (fp != NULL)
	{

		// Run1.body.1.dat output file  ************************************************************
	  fprintf(fp,"%.6e %d %d %d %.4e % .4e % .4e % .4e % .4e % .4e % .4e % .4e % .4e % .4e % .4e \n",
		  (time+sphtime)*tscale,idum, idum, idum, m[p]*mscale,
		  r0[NDIM*p]*rscale, r0[NDIM*p+1]*rscale, r0[NDIM*p+2]*rscale,
		  v0[NDIM*p]*vscale, v0[NDIM*p+1]*vscale, v0[NDIM*p+2]*vscale, 
                  binen*energyscale,sma2*rscale,eccent, period*tscale);

	}
      else 
	{
	  printf("Unable to open file %s\n",temp_file2);
	  exit(0);
	}

      fclose(fp);

    }

/* ------------------------------------------------------------ */
 /* Write tracks to file */
  /*  for (p=0; p<N; p++)
    fprintf(fout,"%lf %lf %lf\n",r0[NDIM*p],r0[NDIM*p+1],r0[NDIM*p+2]);

  fflush(fout);

  printf("Output written\t\tTime : %lf\n",time*tscale);
*/
  toutlast=time;
  toutput=time + dtout;
  
}
