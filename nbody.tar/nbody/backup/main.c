/* MAIN.C
   D. A. Hubber - 20/11/2006
   Main subroutine

compile: make

run:   nbody BD01 <-- id of the sink file

needs: nb.param.dat

   --------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "global.h"
#include "extern_global.h"


/* --------------------------------------------------------------- */
int main(int argc, char *argv[])
{
  int k,p;
  int idum=0,binary_flag=0;
  double E0=0.0;
  double etot=0.0;
  double rcom0[NDIM];
  double vcom0[NDIM];
  double mom0[NDIM];
  double mom[NDIM];
  double rcom[NDIM];
  double vcom[NDIM];
  double x,y,z,vx,vy,vz,lx,ly,lz,l,angle,mass;
  double time1=0, time2=0, dtime=0;
  char param_file[20]="nb.params.dat";
  char output_file[20];
  char fname[30]; 

  FILE *fout;

  sprintf(output_file,"%s.final.dat",argv[1]);
  
  fout = fopen(output_file, "w");

/* Print greetings */
  printf("---------------------------\n");
  printf("Small-N Hermite N-body code\n");
  printf("---------------------------\n\n");

/* Read in parameters for simulation */
  parameters(param_file);

/* Calculate unit conversion factors */
  units();

/* Read in initial conditions file for simulation */
  read_ic(in_file);

/* Convert all physical variables to code units */
  convert_to_code_units(); 


#ifdef BINARYSPHFINAL
/* Search for final binaries and higher-order systems */
  sprintf(fname,"%s.binary.info.final",argv[1]);
  
  binary_search(N,r0,v0,m,fname,time,sphtime);
  printf("\n *** Binaries found! ***\n\n");
  exit(0);
#endif

/* Convert to centre of mass frame */
 
/*  COM(); */

/* Calculate initial energy of the simulation */
  E0 = energy(N,r0,v0,m,mom0);

  printf("E0  : %g\n",E0);
  printf("mom : %g %g %g\n",mom0[0],mom0[1],mom0[2]);

  

/* Create files for first step  */
  output(fout,argv[1]);


/* Main integration loop 
   --------------------------------------------------------------- */
 time1=time;
  do
    {
 
/* Calculate acceleration and jerk and beginning of timestep */
      accel(N,r0,v0,a0,a0one,m);

/* Calculate new time steps for particles */
      basic_timestep();

/* Predictor step */
      predict();

/* Calculate acceleration and jerk at end of timestep */
      accel(N,r,v,a,aone,m);

/* Correction step */
      correction();

/* Check energy conservation */
      // etot=energy(N,r,v,m);

/* Prepare for next step */
      nextstep();

/* Output if required */

if (time>toutput) output(fout,argv[1]);

    } while (time+sphtime < tmax);

/* End of main integration loop 
   -------------------------------------------------------------- */
 

	// output run1.final.dat file ************************************************************************
if (fout != NULL)
  {
    fprintf(fout,"%2d sinks\n",N);
    fprintf(fout,"id/pid/step/time(yr)/mass(Msun)/x/y/z/r(AU)/vx/vy/vz(km/s)/v/lx/ly/lz/l/angle\n");
    for (p=0; p<N; p++) 
      {
	x=(r0[NDIM*p]-r0[0])*rscale;
	y=(r0[NDIM*p+1]-r0[1])*rscale;
	z=(r0[NDIM*p+2]-r0[2])*rscale;
	vx=(v0[NDIM*p]-v0[0])*vscale;
	vy=(v0[NDIM*p+1]-v0[1])*vscale;
	vz=(v0[NDIM*p+2]-v0[2])*vscale;
	mass=m[p]*mscale;
    lx=mass*(y*vz-z*vy); // units come from the units before
	ly=mass*(z*vx-x*vz);
	lz=mass*(x*vy-y*vx);
	l=sqrt(lx*lx+ly*ly+lz*lz);
	if (l>0) 
	  angle=acos(lz/l)*180/3.141519;
	else
		{
	  	//printf("Flipped orbit? Need to upgrade code here!\n");
		//exit(0);
		angle=-100; // this is suspicious!
		}	
			
	fprintf(fout,"%d %d %d %.4e %.4e % .4e % .4e % .4e %.4e % .4e % .4e % .4e %.4e % .4e % .4e % .4e % .4e %.4e\n",
		p+1, idum, idum, (time+sphtime)*tscale, m[p]*mscale,
		(r0[NDIM*p]-r0[0])*rscale,(r0[NDIM*p+1]-r0[1])*rscale,(r0[NDIM*p+2]-r0[2])*rscale,
		rscale* 
		pow((r0[NDIM*p]-r0[0])*(r0[NDIM*p]-r0[0])
		    +(r0[NDIM*p+1]-r0[1])*(r0[NDIM*p+1]-r0[1])
		    +(r0[NDIM*p+2]-r0[2])*(r0[NDIM*p+2]-r0[2]),0.5),
		(v0[NDIM*p]-v0[0])*vscale,(v0[NDIM*p+1]-v0[1])*vscale,(v0[NDIM*p+2]-v0[2])*vscale,
		vscale*
		pow((v0[NDIM*p]-v0[0])*(v0[NDIM*p]-v0[0])
		    +(v0[NDIM*p+1]-v0[1])*(v0[NDIM*p+1]-v0[1])
		    +(v0[NDIM*p+2]-v0[2])*(v0[NDIM*p+2]-v0[2]),0.5),
		lx,ly,lz,l,angle);
      }
  }
 else
   {
     printf("Unable to open file %s\n",output_file);
     exit(0);
   }
 
 fclose(fout);
  
  
/* Search for final binaries and higher-order systems */
  sprintf(fname,"%s.binary.info.dat",argv[1]);

  binary_search(N,r,v,m,fname,time,sphtime);
//  simple_binary_search(N,r0,v0,m);

  printf("Initial energy : %1.10lf\n",E0);
  printf("Initial momentum : %g %g %g\n",mom0[0],mom0[1],mom0[2]);

  etot = energy(N,r,v,m,mom);

  printf("Final energy   : %1.10lf\n",etot);
  printf("Final momentum   : %g %g %g\n",mom[0],mom[1],mom[2]);

  clean_up();

  return 0;
}
