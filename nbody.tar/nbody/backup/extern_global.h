/* EXTERN_GLOBAL.H
   D. A. HUBBER - 16/5/2007
   External declaration of global variables
   ------------------------------------------------------------------ */


#include "prototype.h"


/* Main particle parameters
   ------------------------------------------------------------------ */
extern int N;

extern double *a;
extern double *a0;
extern double *aone;
extern double *a0one;
extern double *atwo;
extern double *athree;
extern double *m;
extern double *r;
extern double *r0;
extern double *v;
extern double *v0;



/* Time variables 
   ------------------------------------------------------------------ */
extern int nmax;    // Maximum number of quantised timesteps

extern int nnow;

extern double dtmin;
extern double dtmax;
extern double time;
extern double dt;
extern double toutput;
extern double toutlast;
extern double sphtime;




/* Input parameters
   ------------------------------------------------------------------ */
extern double tmax;                   // Simulation time
extern double dtout;

extern double eta1;
extern double eta2;

extern double rsink;

extern char in_file[20];
extern char runid[20];


/* Scaling variable strings and conversion factors
   ------------------------------------------------------------------ */
extern char runit[10];              /* length unit   */
extern char munit[10];              /* mass unit     */
extern char tunit[10];              /* time unit     */
extern char vunit[10];              /* velocity unit */
extern char energyunit[10];         /* energy unit   */

extern double rscale;               /* length scaling factor   */
extern double mscale;               /* mass scaling factor     */
extern double tscale;               /* time scaling factor     */
extern double vscale;               /* velocity scaling factor */
extern double energyscale;          /* energy scaling factor   */

extern double rcgs;                 /* length unit in cgs   */
extern double mcgs;                 /* mass unit in cgs     */
extern double tcgs;                 /* time unit in cgs     */
extern double vcgs;                 /* velocity unit in cgs */
extern double energycgs;            /* energy unit in cgs   */


/* Constants 
   ------------------------------------------------------------------ */

/* length units in centimetres */
extern double r_pc;                 /* parsec            */
extern double r_au;                 /* astronomical unit */
extern double r_sun;                /* solar radius      */
extern double r_earth;              /* Earth radius      */

extern double pc_au;                /* parsec (in AU) */
extern double km_cm;                /* km (in cm)     */

/* mass units in grams */
extern double m_sun;                /* solar mass   */
extern double m_jup;                /* Jupiter mass */
extern double m_earth;              /* Earth mass   */


/* time units in seconds */
extern double myr;                  /* megayear */
extern double yr;                   /* year     */
extern double day;                  /* day      */


/* fundamental constants */
extern double m_hydrogen;           /* mass of hydrogen in grams           */
extern double G_const;              /* Gravitational constant in cgs units */
extern double k_boltzmann;          /* Boltzmann constant in cgs units     */
