// TIMESTEP.C
// D. A. Hubber - 21/11/2006
// Calculates a global timestep for all particles
// --------------------------------------------------------

#include <stdio.h>
#include <math.h>
#include "extern_global.h"

// --------------------------------------------------------
void timestep(void)
{
  int i,k,power;
  double acc_mag;
  double jerk_mag;
  double a2_mag;
  double a3_mag;
  double dt1;
  double eta;

#ifdef DEBUG1
  printf("Calculating timestep for all particles\n");
#endif

  dt=9.e20;

  for (i=0; i<N; i++)
    {
      acc_mag=0.0;
      jerk_mag=0.0;
      a2_mag=0.0;
      a3_mag=0.0;
      for (k=0; k<NDIM; k++)
	{
	  acc_mag = acc_mag + a0[NDIM*i + k]*a0[NDIM*i + k]; 
	  jerk_mag = jerk_mag + a0one[NDIM*i + k]*a0one[NDIM*i + k]; 
	  a2_mag = a2_mag + atwo[NDIM*i + k]*atwo[NDIM*i + k];
	  a3_mag = a3_mag + athree[NDIM*i + k]*athree[NDIM*i + k];
	}

      dt1=sqrt(eta2*(acc_mag*a2_mag + jerk_mag*jerk_mag) / 
	       (jerk_mag*a3_mag + a2_mag*a2_mag));

// Select smallest global timestep
      if (dt1<dt) dt=dt1;
    }

// Quantize timestep to powers of 2
  dt1=1.0;
  power=0;
  do
    {
      dt1=dt1/2.0;
      power=power+1;
    } 
  while (dt1>dt);
  
  dt=dt1;
  //  dt=1.0e-3;

#ifdef DEBUG1
  printf("Global timestep = %lf\t",dt);
  printf("Power = %d\n",power);
#endif  

  return;
}
