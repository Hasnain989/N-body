/* NEXTSTEP.C
   D. A. Hubber - 21/11/2006
   Prepare for next step in integration
   ---------------------------------------------------------- */

#include <stdio.h>
#include "extern_global.h"

/* ---------------------------------------------------------- */
void nextstep(void)
{
  int i,k;

  time=time+dt;
  nnow=nnow+1;


#ifdef DEBUG1
  printf("Time - %lf\t\t dt - %lf\n",time*tscale,dt*tscale);
#endif

  for (i=0; i<N; i++)
    {
      for (k=0; k<3; k++)
	{
	  r0[NDIM*i + k]=r[NDIM*i + k];
	  v0[NDIM*i + k]=v[NDIM*i + k];
	  a[NDIM*i + k]=0.0;
	  a0[NDIM*i + k]=0.0;
	  aone[NDIM*i + k]=0.0;
	  a0one[NDIM*i + k]=0.0;
	  atwo[NDIM*i + k]=0.0;
	  athree[NDIM*i + k]=0.0;
	}
    }
}

