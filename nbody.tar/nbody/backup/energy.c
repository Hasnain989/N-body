/* ENERGY.C
   D. A. Hubber - 22/11/2006
   Calculate total energy to check energy conservation
   ---------------------------------------------------------------- */

#include <stdio.h>
#include <math.h>

/* ---------------------------------------------------------------- */
double energy(int N, double *r, double *v, double *m, double mom[NDIM])
{
  int i,j,k;
  double ke,gpe;
  double dr[3];
  double dist, dist2;
  double vsqrd;

  double etot;
  double mtot;
  double rcom[NDIM];
  double vcom[NDIM];
 
  ke=0.0;
  gpe=0.0;

  mtot=0.0;
  for (k=0; k<NDIM; k++) rcom[k]=0.0;
  for (k=0; k<NDIM; k++) vcom[k]=0.0;
  for (k=0; k<NDIM; k++) mom[k]=0.0;

  for (i=0; i<N; i++)
    {
      mtot=mtot + m[i];
      for (k=0; k<NDIM; k++) rcom[k]=rcom[k] + m[i]*r[NDIM*i + k];
      for (k=0; k<NDIM; k++) vcom[k]=vcom[k] + m[i]*v[NDIM*i + k];
      for (k=0; k<NDIM; k++) mom[k]=mom[k] + m[i]*v[NDIM*i + k];
     }

  for (k=0; k<NDIM; k++) rcom[k] = rcom[k]/mtot;
  for (k=0; k<NDIM; k++) vcom[k] = vcom[k]/mtot;

   printf("rcom : %lf %lf %lf\n",rcom[0],rcom[1],rcom[2]);

 


/* First calculate total kinetic energy */
  for (i=0; i<N; i++)
    {
      vsqrd=v[NDIM*i]*v[NDIM*i] + v[NDIM*i + 1]*v[NDIM*i + 1] + 
	v[NDIM*i + 2]*v[NDIM*i + 2];
      ke=ke + 0.5*m[i]*vsqrd;
    }


/* Now gravitational potential energy */
  for (i=0; i<N-1; i++)
    {
      for (j=i+1; j<N; j++)
	{

	  for (k=0; k<3; k++)  dr[k]=r[NDIM*i + k] - r[NDIM*j + k];

	  dist2=dr[0]*dr[0] + dr[1]*dr[1] + dr[2]*dr[2];
	  dist=sqrt(dist2);

	  gpe=gpe - m[i]*m[j]/dist;
	  //	  printf("%lf %lf %lf %lf\n",dist2,dist,m[i],m[j]);
	}
    }

  etot=ke+gpe;


  printf("Kinetic energy is %1.10lf\n",ke);
  printf("Potential energy is %1.10lf\n",gpe);
  printf("Total energy is %1.10lf\n",etot);

  return etot;
}

