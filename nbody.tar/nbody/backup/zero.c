/* ZERO.C
   D. A. Hubber - 21/11/2006
   Zeros main variables. 
   ------------------------------------------------------ */

#include <stdio.h>
#include "extern_global.h"

/* ------------------------------------------------------ */
void zero(void)
{
  int p;                       /* particle counter        */
  int k;                       /* Dimension counter       */

#ifdef DEBUG1
  printf("Zeroing arrays\n");
#endif

  time=0.0;
  toutput=time + dtout;
  toutlast=time;

  nnow=0;

  for (p=0; p<N; p++)
    {
      m[p]=0.0;
      for (k=0; k<3; k++)
	{
	  r[NDIM*p + k]=0.0;
	  r0[NDIM*p + k]=0.0;
	  v[NDIM*p + k]=0.0;
	  v0[NDIM*p + k]=0.0;
	  a[NDIM*p + k]=0.0;
	  a0[NDIM*p + k]=0.0;
	  aone[NDIM*p + k]=0.0;
	  a0one[NDIM*p + k]=0.0;
	  atwo[NDIM*p + k]=0.0;
	  athree[NDIM*p + k]=0.0;
	}
    }

  return;
}
