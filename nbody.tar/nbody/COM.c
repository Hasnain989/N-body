/* COM.C
   D. A. Hubber - 22/11/2006
   Converts to centre of mass frame
   ---------------------------------------------------------------- */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "extern_global.h"


/* ---------------------------------------------------------------- */
void COM(void)
{
  int i,k;

  double mtot;
  double rcom[NDIM];
  double vcom[NDIM];
  double mom[NDIM];
 
#ifdef DEBUG1
  printf("Converting to COM frame\n");
#endif

  mtot=0.0;
  for (k=0; k<NDIM; k++) rcom[k]=0.0;
  for (k=0; k<NDIM; k++) vcom[k]=0.0;
  for (k=0; k<NDIM; k++) mom[k]=0.0;
 
  for (i=0; i<N; i++)
    {
      mtot=mtot + m[i];
      for (k=0; k<NDIM; k++) rcom[k]=rcom[k] + m[i]*r0[NDIM*i + k];
      for (k=0; k<NDIM; k++) vcom[k]=vcom[k] + m[i]*v0[NDIM*i + k];
      for (k=0; k<NDIM; k++) mom[k]=mom[k] + m[i]*v0[NDIM*i + k];

#ifdef DEBUG2
      printf("r[%d] : %g %g %g\n",i,r0[NDIM*i],r0[NDIM*i+1],r0[NDIM*i+2]);
      printf("v[%d] : %g %g %g\n",i,v0[NDIM*i],v0[NDIM*i+1],v0[NDIM*i+2]);
#endif

    }

  for (k=0; k<NDIM; k++) rcom[k] = rcom[k]/mtot;
  for (k=0; k<NDIM; k++) vcom[k] = vcom[k]/mtot;

  printf("\nCentre of mass before translation\n");
  printf("rcom : %g %g %g\n",rcom[0],rcom[1],rcom[2]);
  printf("vcom : %g %g %g\n",vcom[0],vcom[1],vcom[2]);
  printf("mom  : %g %g %g\n",mom[0],mom[1],mom[2]);

  for (k=0; k<NDIM; k++) mom[k]=0.0;

   for (i=0; i<N; i++)
    {
      for (k=0; k<NDIM; k++) r0[NDIM*i+k]=r0[NDIM*i+k] - rcom[k];
      for (k=0; k<NDIM; k++) v0[NDIM*i+k]=v0[NDIM*i+k] - vcom[k];
      
#ifdef DEBUG2
      printf("r[%d] : %g %g %g\n",i,r0[NDIM*i],r0[NDIM*i+1],r0[NDIM*i+2]);
      printf("v[%d] : %g %g %g\n",i,v0[NDIM*i],v0[NDIM*i+1],v0[NDIM*i+2]);
#endif

    }

  mtot=0.0;
  for (k=0; k<NDIM; k++) rcom[k]=0.0;
  for (k=0; k<NDIM; k++) vcom[k]=0.0;
  for (k=0; k<NDIM; k++) mom[k]=0.0;
 
  for (i=0; i<N; i++)
    {
      mtot=mtot + m[i];
      for (k=0; k<NDIM; k++) rcom[k]=rcom[k] + m[i]*r0[NDIM*i + k];
      for (k=0; k<NDIM; k++) vcom[k]=vcom[k] + m[i]*v0[NDIM*i + k];
      for (k=0; k<NDIM; k++) mom[k]=mom[k] + m[i]*v0[NDIM*i + k];
    }

  for (k=0; k<NDIM; k++) rcom[k] = rcom[k]/mtot;
  for (k=0; k<NDIM; k++) vcom[k] = vcom[k]/mtot;

  printf("\nCentre of mass after translation\n");
  printf("rcom : %g %g %g\n",rcom[0],rcom[1],rcom[2]);
  printf("vcom : %g %g %g\n",vcom[0],vcom[1],vcom[2]);
  printf("mom  : %g %g %g\n\n",mom[0],mom[1],mom[2]);


  return;
}
